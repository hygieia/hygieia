(function () {
    'use strict';

    angular
        .module('devops-dashboard')
        .controller('[name]ViewController', [name]ViewController);

    [name]ViewController.$inject = ['$scope'];
    function [name]ViewController($scope) {
        // Set the current scope to ctrl. Then it can be referenced by other private functions
        // to set our public variables
        var ctrl = this;

        // public variables
        ctrl.text = 'Hello World!';
        ctrl.optionsValue = $scope.widgetConfig.options.[name]Field;

        // public methods
        ctrl.load = load;

        /*
         Every controller must have a public load method. It will be called every 60
         seconds and should be where any calls to the data factory are made.
         To have a last updated date show at the top of the widget it must
         return a promise and then resolve it passing a last updated timestamp.
        */
        function load() {
            /*var deferred = $q.defer();
             myDataFactory.getData().then(function(data) {
             // call to processData and set to variables

             // resolve with the last updated date
             deferred.resolve(data.lastUpdated);
             });
             return deferred.promise;
             */
        }
    }
})();
