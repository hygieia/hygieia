(function () {
    'use strict';

    angular
        .module('devops-dashboard')
        .controller('[name]ConfigController', [name]ConfigController);

    [name]ConfigController.$inject = ['modalData', '$modalInstance'];
    function [name]ConfigController(modalData, $modalInstance) {
        var ctrl = this;

        // public variables
        ctrl.text = modalData.widgetConfig.options.[name]Field;

        // public methods
        ctrl.getPreviousValue = getPreviousValue;
        ctrl.showError = showError;
        ctrl.submit = submitConfig;

        // method implementations
        function getPreviousValue() {
            // gets the value from the passed widget configuration if it exists
            return modalData.widgetConfig.options.[name]Field || 'Not set';
        }

        function showError(element) {
            // tell the view whether or not to show errors only once the form has been submitted once
            return element.$invalid && ctrl.submitted;
        }

        function submitConfig(valid) {
            ctrl.submitted = true;

            if(valid) {
                // add our new input to the options
                modalData.widgetConfig.options.[name]Field = ctrl.text;

                // by passing an object back while closing the modal the base widget classes
                // will save it to the api and reload the widget
                $modalInstance.close(modalData.widgetConfig);
            }
        }
    }
})();
