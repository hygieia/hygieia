(function () {
    'use strict';

    var widget_state,
        config = {
        view: {
            defaults: {
                title: '[name]' // widget title
            },
            controller: '[name]ViewController',
            controllerAs: '[name]View', // defaults to ctrl
            templateUrl: 'components/widgets/[name]/view.html'
        },
        config: {
            controller: '[name]ConfigController',
            controllerAs: '[name]Config', // defaults to ctrl
            templateUrl: 'components/widgets/[name]/config.html'
        },
        getState: getState
    };

    angular
        .module('devops-dashboard')
        .config(register);

    register.$inject = ['widgetManagerProvider', 'WIDGET_STATE'];
    function register(widgetManagerProvider, WIDGET_STATE) {
        widget_state = WIDGET_STATE;
        widgetManagerProvider.register('[name]', config);
    }

    // implement custom logic for determining the widget state in this method
    function getState(widgetConfig) {
        return widgetConfig && widgetConfig.id && widgetConfig.options.[name]Field ?
            widget_state.READY :
            widget_state.CONFIGURE;
    }
})();
